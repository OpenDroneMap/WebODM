from app.plugins import PluginBase, MountPoint
from django.http import HttpResponse

class Plugin(PluginBase):
    def app_mount_points(self):
        return [
            MountPoint('/hello/$', lambda request: HttpResponse("Hello!")),
        ]

    def api_mount_points(self):
        return [
            MountPoint('/hello/$', lambda request: HttpResponse("Hello API!")),
        ]

    def serve_public_assets(self, request):
        return request.user.is_authenticated